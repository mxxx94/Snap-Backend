SnapSerializer.prototype.app = 'BeetleBlocks 1.0, http://beetleblocks.com';
SnapSerializer.prototype.thumbnailSize = new Point(480, 360);
