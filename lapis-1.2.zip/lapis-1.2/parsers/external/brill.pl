#!/usr/bin/perl

# LAPIS lightweight structured text processing system
#
# Copyright (C) 1998-2002 Carnegie Mellon University,
# Copyright (C) 2003 Massachusetts Institute of Technology.
# All rights reserved.
#
# This library is free software; you can redistribute it
# and/or modify it under the terms of the GNU General
# Public License as published by the Free Software
# Foundation, version 2.
#
# LAPIS homepage: http://graphics.lcs.mit.edu/lapis/
#

#
#  This script must include, as its first argument, a directory path
# that includes the brill tagger executable (tagger).  There is an
# optional second argument, "getPatterns", that tells the script
# whether to only output the XML defining the patterns returned by
# this parser.  If the argument is not included, then the script will
# read from STDIN and return region sets for all parts-of-speech.
#


if ($ARGV[1] eq "getPatterns") {
    # SHOULD check whether brill tagger exists 
    #  using something like
    #  open TAGGER, "$ARGV[0]" or die " ... maybe some XML here? ..."
  (-x $ARGV[0]) || die "can't execute $ARGV[0]";

    print STDOUT <<'EOF'
<?xml version="1.0"?>
<document>
  <pattern class="CC">English.PartOfSpeech.Conjunction</pattern>
<!--  <pattern class="CD">English.PartOfSpeech.CardinalNumber</pattern> -->
  <pattern class="DT">English.PartOfSpeech.Determiner</pattern>
  <pattern class="EX">English.PartOfSpeech.Existential</pattern>
  <pattern class="FW">English.PartOfSpeech.ForeignWord</pattern>
  <pattern class="IN">English.PartOfSpeech.Preposition</pattern>
  <pattern class="JJ">English.PartOfSpeech.Adjective</pattern>
  <pattern class="JJR">English.PartOfSpeech.Adjective</pattern>  
  <pattern class="JJS">English.PartOfSpeech.Adjective</pattern>
<!--   <pattern class="LS">English.PartOfSpeech.ListItem</pattern> -->
<!--  <pattern class="MD">English.PartOfSpeech.Modal</pattern> -->
  <pattern class="NN">English.PartOfSpeech.Noun</pattern>
  <pattern class="NNS">English.PartOfSpeech.Noun</pattern>
  <pattern class="NNP">English.PartOfSpeech.Noun</pattern>
  <pattern class="NNPS">English.PartOfSpeech.Noun</pattern>
  <pattern class="PDT">English.PartOfSpeech.Determiner</pattern>
  <pattern class="POS">English.PartOfSpeech.PossessiveEnding</pattern>
  <pattern class="PP">English.PartOfSpeech.Noun</pattern>
  <pattern class="PP$">English.PartOfSpeech.Noun</pattern>
  <pattern class="PRP">English.PartOfSpeech.Preposition</pattern>
  <pattern class="RB">English.PartOfSpeech.Adverb</pattern>
  <pattern class="RBR">English.PartOfSpeech.Adverb</pattern>
  <pattern class="RBS">English.PartOfSpeech.Adverb</pattern>
  <pattern class="RP">English.PartOfSpeech.Particle</pattern>
<!--  <pattern class="SYM">English.PartOfSpeech.Symbol</pattern> -->
<!--  <pattern class="TO">English.PartOfSpeech.To</pattern> -->
  <pattern class="UH">English.PartOfSpeech.Interjection</pattern>
  <pattern class="VB">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBD">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBG">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBN">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBP">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBZ">English.PartOfSpeech.Verb</pattern>
  <pattern class="WDT">English.PartOfSpeech.Determiner</pattern>
  <pattern class="WP">English.PartOfSpeech.Noun</pattern>
  <pattern class="WP$">English.PartOfSpeech.Noun</pattern>
  <pattern class="WRB">English.PartOfSpeech.Adverb</pattern>
<!--  <pattern class="PUNC">English.PartOfSpeech.Punctuation</pattern> -->
</document>
EOF

}
else {

# read content from STDIN, and separate punctuation from content
# the tagger requires the content to be in this form before parsing
#
#  ex.  BEFORE: Hello world.  How are you?
#       AFTER:  Hello world .  How are you ?
#
@input = <STDIN>;
$oneline = join('',@input);
$_ = $oneline;
$chars = ".,;'\"!?";

# *** NOT NEEDED ANYMORE ***
#s/[$chars]+/ $&/gs;

# change to tagger's bin directory
chdir $ARGV[0];

# write newly-separated content out to a temporary file
$tempFilePath = "TempTaggerFile$$.txt";
#$osname = $ARGV[1];
open(TEMP, "> " . $tempFilePath);
print TEMP $_;
close(TEMP);

# execute brill tagger
$ENV{PATH}=".:" . $ENV{PATH};
#print STDOUT $ENV{PATH};
open(OUTPUT, "tagger LEXICON $tempFilePath BIGRAMS LEXICALRULEFILE CONTEXTUALRULEFILE |");
@all = <OUTPUT>;
close(OUTPUT);
$oneln = join('', @all);

# begin XML response
print STDOUT "<?xml version=\"1.0\"?>\n";
print STDOUT "<document xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" >\n";

# go through tagged string, find token in original content, and add region set
$pos = 0;
$line = $oneln;
while ($line =~ /[$chars\w\/]+/gs) {
    print STDERR $& . "\n";
    ($Y,$Z) = split('\/', $&);
    print $Y . "," . $Z . "\n";
    $t = index($oneline, $Y, $pos);
    if ($Z =~ /[$chars]/) { $Z = "PUNC"; }
    print "<regionset class=\"" . $Z . "\">";
    print "[" . $t . "," . ($t+length($Y)) . "]</regionset>\n";
    $pos = $t + length($Y);
}

# end XML response
print STDOUT "</document>\n";

# remove temporary file (separated content)
unlink $tempFilePath

}



__END__

This following XML is included to give more descriptive
definitions to classes that were "rolled up" above.

<?xml version="1.0"?>
<document>
  <pattern class="CC">English.PartOfSpeech.Conjunction</pattern>
  <pattern class="CD">English.PartOfSpeech.CardinalNumber</pattern>
  <pattern class="DT">English.PartOfSpeech.Determiner</pattern>
  <pattern class="EX">English.PartOfSpeech.Existential</pattern>
  <pattern class="FW">English.PartOfSpeech.ForeignWord</pattern>
  <pattern class="IN">English.PartOfSpeech.Preposition</pattern>
  <pattern class="JJ">English.PartOfSpeech.Adjective</pattern>
  <pattern class="JJR">English.PartOfSpeech.Adjective</pattern>  
  <pattern class="JJS">English.PartOfSpeech.Adjective</pattern>
  <pattern class="LS">English.PartOfSpeech.ListItem</pattern>
  <pattern class="MD">English.PartOfSpeech.Modal</pattern>
  <pattern class="NN">English.PartOfSpeech.Noun</pattern>
  <pattern class="NNS">English.PartOfSpeech.Noun</pattern>
  <pattern class="NNP">English.PartOfSpeech.Noun</pattern>
  <pattern class="NNPS">English.PartOfSpeech.Noun</pattern>
  <pattern class="PDT">English.PartOfSpeech.Predeterminer</pattern>
  <pattern class="POS">English.PartOfSpeech.PossessiveEnding</pattern>
  <pattern class="PP">English.PartOfSpeech.PersonalPronoun</pattern>
  <pattern class="PP$">English.PartOfSpeech.PossessivePronoun</pattern>
  <pattern class="PRP">English.PartOfSpeech.Preposition</pattern>
  <pattern class="RB">English.PartOfSpeech.Adverb</pattern>
  <pattern class="RBR">English.PartOfSpeech.Adverb</pattern>
  <pattern class="RBS">English.PartOfSpeech.Adverb</pattern>
  <pattern class="RP">English.PartOfSpeech.Particle</pattern>
  <pattern class="SYM">English.PartOfSpeech.Symbol</pattern>
  <pattern class="TO">English.PartOfSpeech.To</pattern>
  <pattern class="UH">English.PartOfSpeech.Interjection</pattern>
  <pattern class="VB">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBD">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBG">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBN">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBP">English.PartOfSpeech.Verb</pattern>
  <pattern class="VBZ">English.PartOfSpeech.Verb</pattern>
  <pattern class="WDT">English.PartOfSpeech.Wh-determiner</pattern>
  <pattern class="WP">English.PartOfSpeech.Wh-pronoun</pattern>
  <pattern class="WP$">English.PartOfSpeech.PossessiveWh-pronoun</pattern>
  <pattern class="WRB">English.PartOfSpeech.Wh-adverb</pattern>
  <pattern class="PUNC">English.PartOfSpeech.Punctuation</pattern>
</document>
