#!/usr/bin/perl

# LAPIS lightweight structured text processing system
#
# Copyright (C) 1998-2002 Carnegie Mellon University,
# Copyright (C) 2003 Massachusetts Institute of Technology.
# All rights reserved.
#
# This library is free software; you can redistribute it
# and/or modify it under the terms of the GNU General
# Public License as published by the Free Software
# Foundation, version 2.
#
# LAPIS homepage: http://graphics.lcs.mit.edu/lapis/
#

use Email::Find;

#
# This script can be called with an optional argument "getPatterns"
#that will tell the script to only output the XML defining the
#patterns returned by this parser.  If the argument is not included,
#then the script will read from STDIN and find all e-mails conforming
#to the RFC specification.
#

if ($ARGV[0] eq "getPatterns") {

print STDOUT << 'EOF'
<?xml version="1.0"?>
<document xmlns:xsi="http://www.w3.org/2001/XMLSchema" 
	  xsi:noNamespaceSchemaLocation="file:///home/noto/lapis/lapis.xsd">
  <pattern class="email">Internet.EmailAddressRFC</pattern>
</document>

EOF
}
else {

# read content from STDIN
@input = <STDIN>;
$oneline = join('',@input);

# begin XML response
print STDOUT "<?xml version=\"1.0\"?>\n";
print STDOUT "<document xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" >\n";

# Simply print out all the addresses found leaving the text undisturbed.
my $finder = Email::Find->new(sub {
    my($email, $orig_email) = @_;
    $pos = -1;
    while (($pos = index($oneline, $email->format, $pos)) > -1) {
	print STDOUT "<regionset class=\"email\">[".$pos.",".($pos+(length($email->format)))."]</regionset>\n";
	$pos++;
    }
    return $orig_email;
});
$finder->find(\$oneline);

# end XML response
print STDOUT "</document>\n";

}#end else
